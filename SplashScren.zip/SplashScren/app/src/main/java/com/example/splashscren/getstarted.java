package com.example.splashscren;

interface getstarted {
}
